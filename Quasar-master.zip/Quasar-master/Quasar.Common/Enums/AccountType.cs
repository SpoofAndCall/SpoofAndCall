﻿namespace Quasar.Common.Enums
{
    public enum AccountType
    {
        Admin,
        User,
        Guest,
        Unknown
    }
}
