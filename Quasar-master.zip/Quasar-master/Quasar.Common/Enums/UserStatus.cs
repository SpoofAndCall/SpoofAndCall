﻿namespace Quasar.Common.Enums
{
    public enum UserStatus
    {
        Active,
        Idle
    }
}
